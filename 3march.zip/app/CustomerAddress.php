<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerAddress extends Model
{
    //
    
    
     protected $guarded = [];
     protected $table = 'customer_address';
}
