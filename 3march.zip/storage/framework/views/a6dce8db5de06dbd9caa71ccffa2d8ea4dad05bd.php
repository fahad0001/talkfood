<?php $__env->startSection('style'); ?>
<style>

    .navbar-default .nav>li>a, .navbar-default .nav>li>a {
        color: #222 !important;
    }
    body {
        background-color: #f5f5f5 !important;
    }
    b, strong {
        font-weight: 500 !important;
    }

    .rest {
        color:#222;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.layout.navigation2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section style="padding-top:70px;">

    <div class='container' >


        <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <h2>Cart</h2>
                <?php if(Session::has('cart') ): ?>
                <div class="table-responsive">
                  
                    <form action="<?php echo e(URL::to('/updatecart')); ?>" method="POST" >
                    <table class="table table-bordered">
                        <thead>
                            <tr> <th></th> <th>Item Name</th> <th>Item Description</th> <th>Item Quantity</th> <th>Item Price</th> </tr>
                        </thead> 
                        <tbody>
                            
                                    <?php echo e(csrf_field()); ?>

                            <?php $i=1;?>
                             <?php foreach($cart as $item): ?> 
                                <?php if(!is_array($item)): ?>
                                
                                <?php else: ?>
                                <tr> <th scope="row"><a href="<?php echo e(URL::to('/cart/delete')); ?>/<?php echo e($item['food_id']); ?>"><i class='fa fa-2x fa-close' style="color:red;"></i></a></th>
                                <td><?php echo e($item['food_name']); ?>

                                    <?php if($item['submenu_status']==1): ?>
                                    <p style='font-size:12px;'>
                                        <?php echo e($item['subitem']['name']); ?>

                                    </p>
                                    
                                    <?php endif; ?>
                                
                                </td> 
                                <td><?php echo e($item['food_desc']); ?></td> 
                                <td><input type='number' name="items[<?php echo e($item['food_id']); ?>]" value='<?php echo e($item['quantity']); ?>' /></td> 
                                
                                <td>$  <?php if($item['submenu_status']==1): ?> <?php echo e($item['food_price']+$item['subitem']['price']); ?><?php else: ?> <?php echo e($item['food_price']); ?> <?php endif; ?> </td>
                                
                            </tr> 
                                <?php endif; ?>
                              <?php endforeach; ?>
                              
                   
                        </tbody>
                    

                    </table>
                         <button class="btn btn-primary" type="submit" >Update Cart</button>
                         <a class="btn btn-primary" href="<?php echo e(URL::to('/')); ?>/rest/<?php echo e(Session::get('currentrest')); ?>"> Continue Shopping </a>
                    </form>
                </div>
                <form action="<?php echo e(URL::to('/cart/checkout')); ?>" id="ad" method="POST">
               <div class="col-md-8 "> 
               <?php echo e(csrf_field()); ?>

                   <h3><b>Is Delivery Address Same as Home Address?</b> <input type="checkbox" name="addresstype" id="delivery_check"></h3> 
                   <div id="delivery_tab" >        
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="street">Street</label>
                        <div class="col-sm-4" style="margin-bottom:20px;">
                            <input type="text" class="form-control" id="street" name="street" placeholder=" Street" data-parsley-required>
                        </div>
                        <label class="control-label col-sm-2" for="city">City</label>
                        <div class="col-sm-4" style="margin-bottom:20px;">
                            <input type="text" class="form-control" name="city" placeholder=" City" data-parsley-required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="state">State/Province</label>
                        <div class="col-sm-4" style="margin-bottom:20px;">
                            <input type="text" class="form-control" name="state" placeholder=" State/Province" data-parsley-required>
                        </div>
                        <label class="control-label col-sm-2" for="country">Country</label>
                        <div class="col-sm-4" style="margin-bottom:20px;">
                            <input type="text" class="form-control" name="country" placeholder=" Country" data-parsley-required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="zip">Zip/Postal Code</label>
                        <div class="col-sm-4" style="margin-bottom:20px;">
                            <input type="text" class="form-control" name="zip" placeholder=" Zip/Postal Code" data-parsley-required>
                        </div>
                        <label class="control-label col-sm-2" for="phone">Phone Number</label>
                        <div class="col-sm-4" style="margin-bottom:20px;">
                            <input type="text" class="form-control " name="phone" placeholder=" Phone Number" data-parsley-required>
                        </div>
                    </div>
                    </div>


            

                                 
                
               </div>

               <div class='col-md-4 '>
                    <h1><b>Cart Totals</b></h1>
                   <div class="table-responsive">
                       <table class="table table-bordered"> 
                           
                           <tbody>
                               <tr>
                                   <td> <h4><b>Subtotal </b> </h4></td> 
                                   <td style='    vertical-align: middle;'>
                                       
                                   $<?php echo e($subtotal); ?> CAD
                                   </td> 
                               </tr>
                               <tr>
                                   <td> <h4><b>Delivery Fee </b> </h4></td> <td style='    vertical-align: middle;'>$<?php echo e($shipping); ?> CAD</td> 
                               </tr>
                               <tr>
                                   <td> <h4><b>Delivery Tax </b> </h4></td> <td style='    vertical-align: middle;'>$<?php echo e($shippingtax); ?> CAD</td> 
                               </tr>
                               <tr>
                                   <td> <h4><b>Tax </b> </h4></td> <td style='    vertical-align: middle;'>$<?php echo e($tax); ?> CAD</td> 
                               </tr>
                               <tr>
                                   <td> <h4><b>Driver Tip<span id="dtip">(10%)</span></b> </h4></td> <td style='vertical-align: middle;'>$<span id="dtipv"><?php echo e($drivertip); ?></span> CAD <button data-toggle="modal" data-target="#myModal"class="btn btn-primary">Change</button> </td> 
                               </tr>
                                <tr>
                                   <td> <h4><b>Total </b> </h4></td> <td style='    vertical-align: middle;'>$<span id="tt"><?php echo e($total); ?></span> CAD</td> 
                               </tr>
                           </tbody> 
                           
                   
                       </table>
                                <div class="modal fade"  id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Change Tip</h4>
      </div>
      <div class="modal-body" style="text-align:center;">
      
       <div class="btn-group" data-toggle="buttons" style="width:270px;">
  <label class="btn btn-primary">
    <input type="radio" name="options" id="option1"  value="2.5" > 2.5%
  </label>
  <label class="btn btn-primary active">
    <input type="radio" name="options" id="option2"   value="10" checked>10%(Recommended)
  </label>
  
</div>

      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
                       <button class="btn btn-primary" type="submit" style='width:100%;'>Place Order<i class='fa fa-arrow-right'></i></button>
                       <H4><b>Note: Only Debit or Credit upon Delivery</b></h4>
                   </div>
                   
                   
          
                   
                   
                  </form>
                    
                  
                   
                   
                   
                  
                    
                </div>

                <?php else: ?> 
                
                <H1>Cart is empty !</H1>
                
              <?php endif; ?>



            </div>
         
        </div>

    </div>


</div>


</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
     <?php if(Session::has('cart')): ?>
    var ttip=(10/100)*<?php echo e($subtotal); ?>;
    $("#tt").text((<?php echo e($total); ?>+ttip).toFixed(2));
    <?php endif; ?>
    
      $('#ad').parsley();
        $("#delivery_check").click(function () {
            $("#delivery_tab").toggle();
            if($("#delivery_tab").css('display')=="none") {
            
             $('#ad').parsley().destroy();
           
            
            }
            else {
             $('#ad').parsley();
           
            }
        });
        
        <?php if(Session::has('cart')): ?>
       $("#option1").change(function(){
    // Do something interesting here
        var tip=(2.5/100)*<?php echo e($subtotal); ?>;
        $("#dtipv").text((tip).toFixed(2));
        $("#dtip").text("(2.5%)");
        $("#myModal").modal('hide');
         $("#tt").text((<?php echo e($total); ?>+tip).toFixed(2));
        
        });
  $("#option2").change(function(){
    // Do something interesting here
       var tip=(10/100)*<?php echo e($subtotal); ?>;
         $("#dtipv").text((tip).toFixed(2));
          $("#dtip").text("(10%)");
          $("#myModal").modal('hide');
           $("#tt").text((<?php echo e($total); ?>+tip).toFixed(2));
});
       <?php endif; ?>
      
    });
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>