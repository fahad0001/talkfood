<?php $__env->startSection('title'); ?>
Restaurant Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
                
            </div>
            <div class="box-body table-responsive no-padding">


                    <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <div class="col-sm-6">
                     <h1>Customer Details</h1>
                    <h3><b>Customer Id : <?php echo e($custdetail->id); ?></b></h3>
                    <h4>First Name  : <?php echo e($custdetail->first_name); ?></h4>
                     <h4>Last Name : <?php echo e($custdetail->last_name); ?></h4>
                  <h4>Email : <?php echo e($custdetail->email); ?></h4>
                  
                </div>
                <?php foreach($custAddress as $i): ?>
 <div class="col-sm-6">
 		<?php if($i->address_type==='ship'): ?>
                     <h3>Shipping Address</h3>
                    <h3>Street : <?php echo e($i->street); ?></h3>
                    <h4>City : <?php echo e($i->city); ?></h4>
                     <h4>State\Province : <?php echo e($i->state_province); ?></h4>
                     <h4>Country : <?php echo e($i->country); ?></h4>
                     <h4>Zip Code : <?php echo e($i->zip_code); ?></h4>
                     <h4>Phone No : <?php echo e($i->phone_no); ?></h4>
                </div>
                <?php elseif($i->address_type==='del'): ?>
                 <h3>Delivery Address</h3>
                    <h3>Street : <?php echo e($i->street); ?></h3>
                    <h4>City : <?php echo e($i->city); ?></h4>
                     <h4>State\Province : <?php echo e($i->state_province); ?></h4>
                     <h4>Country : <?php echo e($i->country); ?></h4>
                     <h4>Zip Code : <?php echo e($i->zip_code); ?></h4>
                     <h4>Phone No : <?php echo e($i->phone_no); ?></h4>
                </div>
                <?php elseif($i->address_type==='bill'): ?>
                 <h3>Billing Address</h3>
                    <h3>Street : <?php echo e($i->street); ?></h3>
                    <h4>City : <?php echo e($i->city); ?></h4>
                     <h4>State\Province : <?php echo e($i->state_province); ?></h4>
                     <h4>Country : <?php echo e($i->country); ?></h4>
                     <h4>Zip Code : <?php echo e($i->zip_code); ?></h4>
                     <h4>Phone No : <?php echo e($i->phone_no); ?></h4>
                </div>
                <?php endif; ?>
         <?php endforeach; ?>
     <a href="<?php echo e(URL::to('admin/viewcustomer')); ?>" class="btn btn-danger"> Back to Customer</a>
            </div>
            </div>
           







                
            </div>
        </div>
        
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>