<?php $__env->startSection('title'); ?>
Restaurant Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8">
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Food</h3>
            </div>

    <form class="form-horizontal" role="form" action="<?php echo e(URL::to('restaurant/editmenuitem')); ?>/<?php echo e($food->food_id); ?>" method="POST">
         <?php echo e(Csrf_field()); ?>

             

<div class="box-body">
        <div class="form-group">
            <label for="DishType" class="col-md-3 control-label">Category:</label>
            <div class="col-md-6">
               <select name="categ_id" class="form-control">
                            <?php foreach($categs as $categ): ?>
                            <option value="<?php echo e($categ->cate_id); ?>"  > <?php echo e($categ->cate_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                
            </div>
            
            
        </div>
    <div class="form-group">
        <label for="DishType" class="col-md-3 control-label">Edit Food:</label>
            <div class="col-md-6">
                <input type="text" class="form-control" id="typename" value="<?php echo e($food->food_name); ?>" name="food" placeholder="" required="">
                
            </div>
    </div>
        <div class="form-group">
            <label  class="col-md-3 control-label">Edit Description:</label>
            <div class="col-md-6">
                <textarea type="textarea" class="form-control" id="typename" value="" name="description"><?php echo e($food->food_desc); ?></textarea>
                
            </div>
        </div>
    <div class="form-group">
        <label  class="col-md-3 control-label">Edit Price:</label>
            <div class="col-md-6">
                <input type="text" class="form-control" id="typename" value="<?php echo e($food->food_price); ?>" name="price" placeholder="" required="">
                
            </div>
    </div>
      <div class="form-group">
                     <label  class="col-md-3 control-label">Sub menu:</label>
        <div class="col-md-6" style="    padding-top: 8px;" >
        
         
         
         <!-- sheepIt Form -->
<div id="sheepItForm">
 
  <!-- Form template-->
 <div id="sheepItForm_template">
        <label for="sheepItForm_#index#_phone">Submenu <span id="sheepItForm_label"></span></label>
         <a id="sheepItForm_remove_current">
     Remove
    </a>
   <div>
       <div class="form-group">
        <label for="sheepItForm_#index#_phone" class="col-md-4 control-label">Name <span id="sheepItForm_label"></span></label>
    <div class="col-md-6">
    <input id="sheepItForm_#index#_name" name="submenu[#index#][name]" type="text"/>
    </div>
       </div>
       <div class="form-group">
     <label for="sheepItForm_#index#_phone" class="col-md-4 control-label">Description <span id="sheepItForm_label"></span></label>
     <div class="col-md-6">
     <input id="sheepItForm_#index#_desc" name="submenu[#index#][desc]" type="text"/>
     </div>
       </div>
       <div class="form-group">
      <label for="sheepItForm_#index#_phone" class="col-md-4 control-label">Price <span id="sheepItForm_label"></span></label>
      <div class="col-md-6">
      <input id="sheepItForm_#index#_price" name="submenu[#index#][price]" type="text"/>
      </div>
       </div>
    </div>
  </div>
  <!-- /Form template-->
   
  <!-- No forms template -->
  <div id="sheepItForm_noforms_template">No Submenu</div>
  <!-- /No forms template-->
   
  <!-- Controls -->
  <div id="sheepItForm_controls">
    <div id="sheepItForm_add" class="pull-left" style="padding: 10px;"> <a class="btn btn-primary"><span>Add Submenu</span></a></div>
    <div id="sheepItForm_remove_last" class="pull-left" style="padding: 10px;"><a class="btn btn-primary"><span>Remove</span></a></div>
    
 
  <!-- /Controls -->
   
</div>
<!-- /sheepIt Form -->
         
         </div>
    </div>
       
      </div>
     <div class="form-group">
        <div class="col-md-6 col-md-offset-3">
            <button type="submit" class="btn btn-google">Update</button>
            </div>
    </div>
      
    
</div>
    </form>
    </div>
</div>
       
   
      
  
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
       
       var array=[];
       
       <?php foreach($submenu as $a): ?> 
         var a={'sheepItForm_#index#_name':'<?php echo e($a->name); ?>', 'sheepItForm_#index#_desc':'<?php echo e($a->desc); ?>', 'sheepItForm_#index#_price':<?php echo e($a->price); ?>};
       array.push(a);
       
       <?php endforeach; ?>
     
       
         var sheepItForm = $('#sheepItForm').sheepIt({
        separator: '',
        allowRemoveLast: true,
        allowRemoveCurrent: true,
        allowRemoveAll: true,
        allowAdd: true,
        allowAddN: true,
        maxFormsCount: 10,
        minFormsCount: 0,
        iniFormsCount: 0,
        data:array
    });
       
       
       
 
});

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>