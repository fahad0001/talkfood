<aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      

      <!-- search form (Optional) -->
      
      <!-- /.search form -->
       <!-- Sidebar Menu -->
       <?php echo $__env->yieldContent('sideMenu'); ?>
      <!--<ul class="sidebar-menu">
        <li class="header">HEADER</li>
      </ul>-->
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>