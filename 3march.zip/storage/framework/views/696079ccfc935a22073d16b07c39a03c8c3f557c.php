<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
              <h3 class="box-title">Restuarants</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                  <tbody>
                <?php if(isset($rests)): ?>
                
                <tr>
                  <th>ID</th>
                  <th>Restuarant Name</th>
                  <th>Kitchen Type</th>
                  <th>Date</th>
                  <th>Address</th>
                  <th>Status</th>
                  <th></th>
                  <th></th>
                   <th></th>
                </tr>
                
                        <?php foreach($rests as $rest): ?>
                            <tr>
                            <td><?php echo e($rest->rest_id); ?></td>
                            <td><?php echo e($rest->rest_name); ?></td>
                            <td><?php echo e($rest->kitchen_type); ?></td>
                            <td><?php echo e($rest->created_at->format('m/d/Y')); ?></td>
                            <td><?php echo e($rest->rest_street); ?> <?php echo e($rest->rest_city); ?> <?php echo e($rest->rest_country); ?></td>
                            <td><span class="label label-success"><?php echo e($rest->rest_status); ?></span></td>
                           
                            <td><a href="<?php echo e(URL::to('admin/vieworders')); ?>/<?php echo e($rest->rest_id); ?>">View Orders</a></td>
                             <td><a href="<?php echo e(URL::to('admin')); ?>/<?php echo e($rest->rest_id); ?>/salereport"> View sales</a></td>
                           
                            <td><a href="<?php echo e(URL::to('admin/editrest')); ?>/<?php echo e($rest->rest_id); ?>"> Edit</a></td>
                             <td><a href="<?php echo e(URL::to('admin/deleterest')); ?>/<?php echo e($rest->rest_id); ?>"> Delete</a></td>
                            </tr>                         
                        <?php endforeach; ?>
                    
                    <?php else: ?>
                        <h2>No Restaurant Exists!</h2>
                    
                    <?php endif; ?>
                             
              </tbody>
              </table>
                <div class="box-footer clearfix">
                    <ul class="pagination pagination-sm no-margin pull-right">
                        <?php echo $rests->render(); ?>
                    </ul>
                </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>