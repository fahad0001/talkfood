<?php $__env->startSection('title'); ?>
Order Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
    <form class="form-horizontal" action="<?php echo e(URL::to('/restaurant/editorderdetail/'.$orderinfo['order_id'])); ?>" role="form" method="POST">
            <?php echo csrf_field(); ?>

        <div class="box">
            <div class="box-header">
                <h3>
                    Resturant Order
                </h3>
            </div>
            <div class="container">
            <label for="sel1" >Status :</label>
            <select id="status" name="status" class="selectContainer">
                         <option <?php echo e($orderinfo['order_status'] ==''? 'selected':''); ?> value=""></option>
                         <option <?php echo e($orderinfo['order_status'] =='complete'? 'selected':''); ?> value="complete">Complete</option>
                         <option <?php echo e($orderinfo['order_status'] =='pending'? 'selected':''); ?> value="pending">Pending</option>
                         <option <?php echo e($orderinfo['order_status'] =='canceled'? 'selected':''); ?> value="canceled">Canceled</option>
                         <option <?php echo e($orderinfo['order_status'] =='processing'? 'selected':''); ?> value="processing">Processing</option>
                         </select>
                         </div>
            <div class="box-body table-responsive no-padding">


                    <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <div class="col-sm-6">
                     <h1>Orders Details</h1>
                    <h3><b>Order Id : <?php echo e($orderinfo->order_id); ?></b></h3>
                    <h4>Order quantity : <?php echo e($orderinfo->order_qty); ?></h4>
                     <h4>Order Subtotal : <?php echo e($orderinfo->order_total_without_tax); ?> CAD</h4>
                  <h4>Order Shipping : <?php echo e($orderinfo->order_ship_price); ?> CAD</h4>
                  <h4>Shipping Tax : <?php echo e($orderinfo->order_ship_tax); ?> CAD</h4>
                    <h4>Order Tax : <?php echo e($orderinfo->order_tax); ?> CAD</h4>
                     <h4>Order Total : <?php echo e($orderinfo->order_grand_total); ?> CAD</h4>
                    <h4>Created At: <?php echo e($orderinfo->created_at); ?> </h4>
                </div>
                <div class="col-sm-6">
                    <h3><b>Customer Details</b></h3>
                    <h3>Name : <?php echo e($orderinfo['customer']->first_name); ?> <?php echo e($orderinfo['customer']->last_name); ?></h3>
                    <h5>Address : <?php echo e($orderinfo['customerAddress']->street); ?>,<?php echo e($orderinfo['customerAddress']->city); ?>,<?php echo e($orderinfo['customerAddress']->zip_code); ?>,<?php echo e($orderinfo['customerAddress']->country); ?></h5>

                </div>
 <div class="col-sm-12">
                <div class="table-responsive">

                    <h4><b>Items Details</b></h4>
                    <table class="table table-bordered">
                        <thead>
                            <tr> <th>Item Name</th> <th>Quantity</th><th>Price</th></tr>
                        </thead> 
                        <tbody>
                            <?php foreach($items as $i): ?>
                          <tr>
                                <td>
                                    <?php echo e($i->item_name); ?>

                                    <?php if($i->subitem_id!=null): ?>
                                        
                                    <br> <?php echo e($i['subitem']->name); ?>

                                    
                                    <?php endif; ?>
                                    
                                </td>

                                <td>
                                    <?php echo e($i->item_qty); ?>

                                </td>

                                <td>
                                     <?php if($i->subitem_id!=null): ?>
                                        
                                    <?php echo e(round(floatval($i['subitem']->price)+floatval($i->item_price),2)); ?> CAD
                                    <?php else: ?>
                                    <?php echo e($i->item_price); ?> CAD
                                    <?php endif; ?>
                                    
                                    
                                </td>

                            </tr>


                            <?php endforeach; ?>



                        </tbody>
                    </table>






                </div>
     <!--<a href="<?php echo e(URL::to('/restaurant/editorderdetail/'.$orderinfo['order_id'])); ?>" class="btn btn-danger"> Back to Restaurants</a>-->
     <input type="submit" id="btnsubmit" name="btnsubmit" class="btn btn-danger"> 
            </div>
            </div>
           







        </div>
                
            </div>
        </div>
        </form>
    </div></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>