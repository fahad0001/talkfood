<?php $__env->startSection('title'); ?>
Restaurant Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
Foods
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sideMenu'); ?>
<div class="user-panel">
        <div class="pull-left image">
          <img src="../../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Alexander Pierce</p>
        </div>
      </div>
<ul class="sidebar-menu">
    <li class="header">MAIN NAVIGATION</li>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-dashboard"></i> <span>Order</span>
            <span class="pull-right-container">
              <!--<i class="fa fa-angle-left pull-right"></i>-->
            </span>
        </a>

    </li>
    <li class="treeview active">
        <a href="#">
            <i class="fa fa-dashboard"></i> <span>Food</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <li ><a href="#"><i class="fa fa-circle-o"></i> Add Categories</a></li>
            <li class="active"><a href="#"><i class="fa fa-circle-o"></i> Add Food</a></li>
          </ul>
    </li>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-user"></i> <span>Profile Info</span>
            <span class="pull-right-container">
              <!--<i class="fa fa-angle-left pull-right"></i>-->
            </span>
        </a>
    </li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8 col-md-offset-2">
   <!--<input type="hidden" id="page_name" value="adddishtype">-->

    <form class="form-horizontal" role="form" action="" method="POST">

        <div class="form-group">
            <label for="DishType" class="col-md-2 control-label round">Category:</label>
            <div class="col-md-4">
                <select class="form-control" id="paymentmode" name="category_Drop">
                        <option value="0">1</option><option value="1">2</option><option value="2">3</option>
                    </select>
                
            </div>
            <label for="DishType" class="col-sm-2 control-label">Add Food:</label>
            <div class="col-md-4">
                <input type="text" class="form-control" id="typename" name="food" placeholder="" required="">
                
            </div>
            
        </div>
        <div class="form-group">
            <label  class="col-md-2 control-label">Description:</label>
            <div class="col-md-4">
                <textarea type="textarea" class="form-control" id="typename" name="description"></textarea>
                
            </div>
            <label  class="col-sm-2 control-label">Price:</label>
            <div class="col-md-4">
                <input type="text" class="form-control" id="typename" name="food" placeholder="" required="">
                
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-6">
            <input type="file" class="form-control">
            </div>
            <div class="col-md-4 col-md-offset-2">
            <button type="submit" class="btn btn-microsoft">Submit</button>
            </div>
            
            </div>
       
    </form>
    
     <table class="table table-striped dataTable no-footer" id="tbtable" role="grid" aria-describedby="tbtable_info">
                <thead>
                    <tr role="row" style="background-color:#3c8dbc;color:white;">
                        <th class="sorting_asc" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="SrNo: activate to sort column descending" style="width: 33px;">SrNo</th>
                        <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 238px;">Type Name</th>
                        <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Delete DishType: activate to sort column ascending" style="width: 66px;"></th>
                        <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="View / Update DishType: activate to sort column ascending" style="width: 101px;"></th>
                    </tr>
                </thead>
                <tbody>
                        <tr role="row" class="odd">

                                <td >1</td>                             
                                <td>sweet</td>
                                <td><a href="#">Delete</a></td> 
                                <td><a href="#">View / Update</a></td> 
                            </tr></tbody>
            </table>
    <!--View Table-->
    <!--<h4 class="sub-header">View Category</h4>-->

    <!--End View Table-->

</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>