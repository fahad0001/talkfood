<div class="user-panel">
        <div class="pull-left image">
        <img src="<?php echo e(URL::to('/uploads/'.$rest->rest_logo_path)); ?>">
        </div>
        <div class="pull-left info">
          <p><?php echo e($rest->rest_name); ?></p>
        </div>
</div>
<ul class="sidebar-menu">
    <li class="header">MAIN NAVIGATION</li>
    <li class="treeview">
        <a href="<?php echo e(URL::to('restaurant/index')); ?>">
            <i class="fa fa-dashboard"></i> <span>Order</span>
            <span class="pull-right-container">
              <!--<i class="fa fa-angle-left pull-right"></i>-->
            </span>
        </a>

    </li>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-dashboard"></i> <span>Menu</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(URL::to('restaurant/viewcategory')); ?>"><i class="fa fa-circle-o"></i> Add Categories</a></li>
            <li><a href="<?php echo e(URL::to('restaurant/addmenuitem')); ?>"><i class="fa fa-circle-o"></i> Add Menu Item</a></li>
            <li><a href="<?php echo e(URL::to('restaurant/viewmenuitem')); ?>"><i class="fa fa-circle-o"></i> View Menu Item</a></li>
          </ul>
    </li>
    <li class="treeview">
        <a href="<?php echo e(URL::to('restaurant/viewprofile')); ?>">
            <i class="fa fa-user"></i> <span>Profile Info</span>
            <span class="pull-right-container">
              <!--<i class="fa fa-angle-left pull-right"></i>-->
            </span>
        </a>
    </li>
</ul>