<ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="treeview ">
                <a href="<?php echo e(URL::to('/admin/index')); ?>">
                    <i class="fa fa-dashboard"></i> <span>All Restaurants</span>
                    <span class="pull-right-container">
                      <!--<i class="fa fa-angle-left pull-right"></i>-->
                    </span>
                </a>

            </li>
            <li class="treeview">
                <a href="<?php echo e(URL::to('/admin/settings')); ?>">
                    <i class="fa fa-cog"></i> <span>Setting</span>
                    <span class="pull-right-container">
                      <!--<i class="fa fa-angle-left pull-right"></i>-->
                    </span>
                </a>
            </li>
            <li class="treeview">
                <a href="<?php echo e(URL::to('/admin/commission')); ?>">
                    <i class="fa fa-money"></i> <span>Commission</span>
                    <span class="pull-right-container">
                      <!--<i class="fa fa-angle-left pull-right"></i>-->
                    </span>
                </a>
            </li>
           
        </ul>