<?php $__env->startSection('style'); ?>
<style>

    .navbar-default .nav>li>a, .navbar-default .nav>li>a {
        color: #222 !important;
    }
    body {
        background-color: #f5f5f5 !important;
    }
    b, strong {
        font-weight: 500 !important;
    }

    .rest {
        color:#222;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.layout.navigation2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section style="padding-top:70px;">

    <div class='container' >


        <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <div class="col-sm-6">
                    <h1>Orders Details</h1>
                    <h3><b>Order Id : <?php echo e($orderinfo->order_id); ?></b></h3>
                    <h4>Order quantity : <?php echo e($orderinfo->order_qty); ?></h4>
                    <h4>Order Total : <?php echo e($total); ?> CAD</h4>
                    <h4>Created At: <?php echo e($orderinfo->created_at); ?> </h4>
                </div>
                <div class="col-sm-6">
                    <h1>Customer Details</h1>
                    <h3><b>Name : <?php echo e($orderinfo['customer']->first_name); ?><?php echo e($orderinfo['customer']->last_name); ?></b></h3>
                    <h4>Address : <?php echo e($orderinfo['customerAddress']->street); ?>,<?php echo e($orderinfo['customerAddress']->city); ?>,<?php echo e($orderinfo['customerAddress']->zip_code); ?>,<?php echo e($orderinfo['customerAddress']->country); ?></h4>

                </div>
 <div class="col-sm-12">
                <div class="table-responsive">

                    <h4><b>Items Details</b></h4>
                    <table class="table table-bordered">
                        <thead>
                            <tr> <th>Item Name</th> <th>Quantity</th><th>Price</th></tr>
                        </thead> 
                        <tbody>
                            <?php foreach($items as $i): ?>
                            <tr>
                                <td>
                                    <?php echo e($i->item_name); ?>

                                </td>

                                <td>
                                    <?php echo e($i->item_qty); ?>

                                </td>

                                <td>
                                    <?php echo e($i->item_price); ?> CAD
                                </td>

                            </tr>

                            <?php endforeach; ?>



                        </tbody>
                    </table>






                </div>
     <a href="<?php echo e(URL::to('customer/account')); ?>" class="btn btn-danger"> Back to Orders</a>
            </div>
            </div>
           







        </div>

    </div>

</div>


</div>


</section>

<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>