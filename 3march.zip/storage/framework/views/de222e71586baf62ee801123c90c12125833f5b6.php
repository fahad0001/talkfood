<?php $__env->startSection('style'); ?>
<style>

    .navbar-default .nav>li>a, .navbar-default .nav>li>a {
        color: #222 !important;
    }
    body {
        background-color: #f5f5f5 !important;
    }
    b, strong {
        font-weight: 500 !important;
    }

    .rest {
        color:#222;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.layout.navigation2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section style="padding-top:70px;">

    <div class='container' >


        <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <h2>Orders</h2>
               
                  <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
              
                    <?php echo e(Session::get('message')); ?><br>        
               </div>
                  <?php endif; ?>
                <div class="table-responsive">
                  
                  <?php if(count($orders)>=1): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr> <th>Order Id</th> <th>Quantity</th><th>Total</th><th>Status</th><th>Created at</th>  </tr>
                        </thead> 
                        <tbody>
                            
                               <?php foreach($orders as $order): ?>
                               <tr>
                                   <td>
                                       <?php echo e($order->order_id); ?>

                                       <a style="color:red;" href="<?php echo e(URL::to('customer/orders')); ?>/<?php echo e($order->order_id); ?>">View</a>
                                   </td>
                                   
                                    <td>
                                       <?php echo e($order->order_qty); ?>

                                   </td>
                                   
                                     <td>
                                       <?php echo e($order->order_total_amount); ?> CAD
                                     </td>
                                     <td>
                                       <?php echo e($order->order_status); ?>

                                   </td>
                                   
                                   <td>
                                       <?php echo e($order->created_at); ?>

                                   </td>
                               </tr>
                              
                            
                              <?php endforeach; ?>
                              
                   
                        </tbody>
                    </table>
                  
                  <?php else: ?>
                  
                  <h3>No order History</h3>
                  <?php endif; ?>
                      
                    
                </div>
               

            

               



            </div>
         
        </div>

    </div>


</div>


</section>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>