<nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand page-scroll" href="<?php echo e(URL::to('/')); ?>">TalkFood</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="page-scroll" href="<?php echo e(URL::to('/login')); ?>">Login</a>
                </li>
                <li>
                    <a class="page-scroll" href="<?php echo e(URL::to('/signup')); ?>">Sign Up</a>
                </li>
                <li>
                    <a class="page-scroll" href="#contact">Contact</a>
                </li>
                <?php if(isset($currentUser)): ?>
                <?php if($currentUser->role=="cus"): ?>
                <li>
                    <a href="<?php echo e(URL::to('/customer/account')); ?>" class="page-scroll">Account
                    </a>
                </li><li>
                    <a href="<?php echo e(URL::to('logout')); ?>" class="page-scroll">Logout
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(URL::to('/cart')); ?>" class="page-scroll">Cart <span id="cartcount" class="badge"><?php if(isset($cart)): ?> <?php echo e(Session::get('cart')['totalquantity']); ?> <?php elseif(Session::has('cart')): ?> <?php echo e(Session::get('cart')['totalquantity']); ?><?php else: ?> <?php echo e(0); ?>  <?php endif; ?></span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
</nav>