<?php $__env->startSection('title'); ?>
Restaurant Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8">
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add Menu Item</h3>
                </div>
    <form class="form-horizontal" role="form" action="<?php echo e(URL::to('restaurant/addmenuitem')); ?>" method="POST">
         <?php echo e(Csrf_field()); ?>

<div class="box-body">
        <div class="form-group">
            <label for="DishType" class="col-md-3 control-label">Category:</label>
            <div class="col-md-6">
               <select name="categ_id" class="form-control">
                            <?php foreach($categs as $categ): ?>
                            <option value="<?php echo e($categ->cate_id); ?>" > <?php echo e($categ->cate_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                
            </div>
            
            
        </div>
    <div class="form-group">
        <label for="DishType" class="col-md-3 control-label">Item Name:</label>
            <div class="col-md-6">
                <input type="text" class="form-control" id="typename" name="food" placeholder="" required="">
                
            </div>
    </div>
        <div class="form-group">
            <label  class="col-md-3 control-label">Description:</label>
            <div class="col-md-6">
                <textarea type="textarea" class="form-control" id="typename" name="description"></textarea>
                
            </div>
        </div>
    <div class="form-group">
        <label  class="col-md-3 control-label">Price:</label>
            <div class="col-md-6">
                <input type="text" class="form-control" id="typename" name="price" placeholder="" required="">
                
            </div>
    </div>
       
    <div class="form-group">
        <div class="col-md-6 col-md-offset-3">
            
            <button type="submit" class="btn btn-google">Submit</button>
            </div>
    </div>
       <div class="box-body">
    </form>
</div>
</div>
    
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>