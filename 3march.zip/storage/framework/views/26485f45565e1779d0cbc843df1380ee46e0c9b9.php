<?php $__env->startSection('style'); ?>
<style>

    .navbar-default .nav>li>a, .navbar-default .nav>li>a {
        color: #222 !important;
    }
    body {
        background-color: #f5f5f5 !important;
    }
    b, strong {
        font-weight: 500 !important;
    }
    
    .rest {
        color:#222;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.layout.navigation2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section style="padding-top:70px;">

    <div class='container' >

        <div class='row'>

            <h3><b><?php echo e(count($data)); ?> restaurants near you !</b></h3>


        </div>
        <div class='row'>
            <div class='col-sm-12' style='background-color: white;min-height: 800px;'>
                
                <?php foreach($data as $d): ?>
                <div class='col-sm-6' style='padding-top:20px;'>
                    <a href="<?php echo e(URL::to('/rest')); ?>/<?php echo e($d->rest_id); ?>" class='rest'>
                    <div class='col-sm-3'>  
                        <img src='https://d2egcvq7li5bpq.cloudfront.net/ca/images/restaurants/5651.gif' style="width:100%;" /> 
                    </div>
                    <div class='col-sm-9'>
                        <div >
                            <h3 style='margin-top:5px;'><b><?php echo e($d->rest_name); ?></b></h3>
                            <p style='margin-bottom: 2px;'> Kitchen Type </p>
                            <p style='margin-bottom: 2px;'> Address </p>
                        </div>

                       
                    </div> 
                         </a>

                </div>

                <?php endforeach; ?>
            </div>

        </div>

    </div>


</div>


</section>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>