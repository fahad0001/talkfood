<aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      

      <!-- search form (Optional) -->
      
      <!-- /.search form -->
       <!-- Sidebar Menu -->
  
       
       
       
       <?php if($currentUser->role=='rest'): ?>
       <?php echo $__env->make('layout.restNavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <?php endif; ?>
       
       <?php if($currentUser->role=='admin'): ?>
       <?php echo $__env->make('layout.adminNavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <?php endif; ?>
      <!--<ul class="sidebar-menu">
        <li class="header">HEADER</li>
      </ul>-->
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>