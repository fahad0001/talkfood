<?php $__env->startSection('title'); ?>
Order Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
Restarant
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-7 col-sm-offset-2 col-md-8 col-md-offset-2 main">
        <form class="form-horizontal" action="<?php echo e(URL::to('/restaurant/editorderdetail/'.$orderdetail['order_id'])); ?>" role="form" method="POST">
            <?php echo csrf_field(); ?>

            <table class="table table-striped">
                <tbody>
                 <tr>
                     <th>OrderId: </th>
                     <td colspan="2"><?php echo e($orderdetail['order_id']); ?></td>
                 </tr>
                 <tr>
                     <th>Customer Name: </th>
                     <td colspan="2"><?php echo e($orderdetail['customer']['first_name']); ?></td>
                 </tr>
                 <tr>
                     <th>Email: </th>
                     <td colspan="2"><?php echo e($orderdetail['customer']['email']); ?></td>
                 </tr>
                 <tr>
                     <th>Date\Time: </th>
                     <td colspan="2"><?php echo e($orderdetail['order_date']); ?></td>
                 </tr>
                 
                <tr>
                    <th>Dish: </th>
                    <th>Quantity: </th>
                    <th>Price: </th>

                </tr>
                <?php foreach($orderItemDetail as $orderItem): ?>
                <tr role="row" class="odd">

                    <td class="sorting_1"><?php echo e($orderItem->item_name); ?></td>
                    <td><?php echo e($orderItem->item_qty); ?></td>
                    <td><?php echo e($orderItem->item_price); ?></td>
                    <?php $counter+=$orderItem->item_qty * $orderItem->item_price; ?>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="2">Amount: </th>
                    <td><input type="hidden" id="amount" name="amount" value="50"><?php echo e($counter); ?></td>
                </tr>
                <tr>
                    <th>Status: </th>
                    <td colspan="2"><select id="status" name="status">
                         <option <?php echo e($orderdetail['order_status'] ==''? 'selected':''); ?> value=""></option>
                         <option <?php echo e($orderdetail['order_status'] =='complete'? 'selected':''); ?> value="complete">Complete</option>
                         <option <?php echo e($orderdetail['order_status'] =='pending'? 'selected':''); ?> value="pending">Pending</option>
                         <option <?php echo e($orderdetail['order_status'] =='canceled'? 'selected':''); ?> value="canceled">Canceled</option>
                         <option <?php echo e($orderdetail['order_status'] =='processing'? 'selected':''); ?> value="processing">Processing</option>
                         </select>
                    </td>
                </tr>
            </tbody>
            </table>

            <input type="submit" id="btnsubmit" name="btnsubmit" class="btn btn-default">                    
           
        </form>
         <!--<input type="submit" id="btntable" name="btntable" class="btn btn-danger"> -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>