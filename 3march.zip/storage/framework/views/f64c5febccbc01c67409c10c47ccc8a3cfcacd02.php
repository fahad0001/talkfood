<?php $__env->startSection('style'); ?>
<style>

    .navbar-default .nav>li>a, .navbar-default .nav>li>a {
        color: #222 !important;
    }
    body {
        background-color: #f5f5f5 !important;
    }
    b, strong {
        font-weight: 500 !important;
    }


</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.layout.navigation2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section style="padding-top:70px;">

    <div class='container' >

        <div class='row'>

          


        </div>
        <div class='row' style=>
            <div class="col-sm-2">
                <p style="margin:0px;"> <i class="fa fa-glass"></i><b> Categories</b></p>
                <div class="col-sm-12" style='background-color: white;'>
                
                <?php foreach($cats as $c): ?>
                <div>
                <a href="#<?php echo e($c->cate_name); ?>" style="color:#222;"><?php echo e(strtoupper($c->cate_name)); ?> </a>
                </div>
                
                <?php endforeach; ?>
                </div>
            </div>
            <div class='col-sm-10' style='background-color: white;min-height: 800px'>
                <h3><b> <?php echo e($restinfo->rest_name); ?></b> </h3>
                <?php foreach($cats as $c): ?>
                <div class="col-md-12" id="<?php echo e($c->cate_name); ?>" >

                    <h3 > <?php echo e(strtoupper($c->cate_name)); ?></h3>
                </div>
                <?php foreach($data as $d): ?>

                <?php if($d->cate_id == $c->cate_id): ?>
                <div class="col-md-12" style="overflow:hidden;">
                    <div class="col-xs-9">
                        <h3 ><b> <?php echo e($d->food_name); ?></b></h3>
                        <h4><?php echo e($d->food_desc); ?></h4>


                    </div>
                    <div class="col-xs-3">
                        <h4><b><?php echo e($d->food_price); ?> CAD</b><span style="text-decoration: none; color:#337ab7;" onclick="addtocart(<?php echo e($d->food_id); ?>)"> <i class="fa fa-2x fa-plus-square"style="vertical-align: middle;font-size: 25px;"></i></span></h4>


                    </div>
                </div>
                <?php endif; ?>
               <hr style="    max-width: 100%;border: 1px solid #eee;">
                <?php endforeach; ?>

               
                <?php endforeach; ?>
            </div>

        </div>

    </div>


</div>


</section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    
   
    function addtocart(id) {
    $.ajax({
  method: "GET",
  url: "<?php echo e(URL::to('/addtocart')); ?>/"+id,
  
})
  .done(function( msg ) {
         
         var cartcount=$('#cartcount').text();
          var count=parseInt(cartcount)+1;
             $('#cartcount').html(count);
         alert(count);
    alert( "Data Saved: " + msg );
  })
  .fail(function(error) {
    alert( error );
    console.log(error);
  });
    
    }
    
    
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>