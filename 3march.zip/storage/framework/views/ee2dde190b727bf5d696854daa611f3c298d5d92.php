<?php $__env->startSection('title'); ?>
Restaurant Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <form class="form-horizontal" role="form" method="POST">
            <div class="box">
                <div class="box-header">
                    <h3>
                        Foods
                    </h3>
                </div>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-bordered" id="tbtable" role="grid" aria-describedby="tbtable_info">
                        <thead>
                            <tr role="row">
                                <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 238px;">Name</th>
                                <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 238px;">Category</th>
                                <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 338px;">Description</th>
                                <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Delete DishType: activate to sort column ascending" style="width: 66px;">Price</th>                        
                                <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="View / Update DishType: activate to sort column ascending" style="width: 101px;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($foodDetail as $food): ?>
                            <tr role="row" class="odd">
                                <td ><?php echo e($food['food_name']); ?></td>                             
                                <td><?php echo e($food['foodCategory']['cate_name']); ?></td>
                                <td><?php echo e($food['food_desc']); ?></td>
                                <td><?php echo e($food['food_price']); ?></td>
                                
                                <td><a href="<?php echo e(URL::to('restaurant/editmenuitem/'.$food['food_id'])); ?>">Edit</a></td> 
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>


    </div>
    <?php if(isset($subfood)): ?>
    <div class="col-md-4">
        <div class="box">
            <div class="box-header">
                <h3>
                    Sub Item
                </h3>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-bordered" id="tbtable" role="grid" aria-describedby="tbtable_info">
                    <thead>
                        <tr role="row">
                            <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 238px;">Name</th>
                            <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 338px;">Description</th>
                            <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 238px;">Price</th>
                            <th class="sorting" tabindex="0" aria-controls="tbtable" rowspan="1" colspan="1" aria-label="Type Name: activate to sort column ascending" style="width: 238px;"></th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($subfood as $sub): ?>
                            <tr role="row" class="odd">
                                <td ><?php echo e($sub['name']); ?></td>                             
                                <td><?php echo e($sub['desc']); ?></td>
                                <td><?php echo e($sub['price']); ?></td>                                
                                <td><a href="<?php echo e(URL::to('restaurant/viewsubitem/'.$sub['id'])); ?>">Edit</a></td> 
                            </tr>
                            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>