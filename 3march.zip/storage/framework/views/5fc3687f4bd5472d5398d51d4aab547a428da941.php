 <footer>
        <div class="container">
            <p>&copy; 2016 TalkFood. All Rights Reserved.</p>
            <ul class="list-inline">
                <li>
                    <a href="https://www.talkfood.org/privacy-policy">Privacy</a>
                </li>
                <li>
                    <a href="https://www.talkfood.org/terms-of-service">Terms</a>
                </li>
                <li>
                    <a href="https://www.talkfood.org/faq">FAQ</a>
                </li>
            </ul>
        </div>
    </footer>