<?php $__env->startSection('content'); ?>
<div class="row">
    
   <div class="col-md-6">
       <div class="col-md-12">
        <div class="box">
            
            <div class="box-header">
                
            <a class="btn btn-primary pull-right" href="<?php echo e(URL::to('/admin/commission/create')); ?>"> Add</a>
              <h3 class="box-title">Commission Group</h3>
              
            </div>
       
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
                
              <table class="table table-hover">
                  <tbody>
                <?php if(isset($comms)): ?>
                
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Percent</th>
                  <th></th>
                </tr>
                
                        <?php foreach($comms as $comm): ?>
                            <tr>
                            <td><?php echo e($comm->commis_id); ?></td>
                            <td><?php echo e($comm->commis_type); ?></td>
                            <td><?php echo e($comm->commis_percent); ?></td>
                            <td><a href="<?php echo e(URL::to('/admin/commission/delete')); ?>/<?php echo e($comm->commis_id); ?>"> Delete</a></td>
                            </tr>                         
                        <?php endforeach; ?>
                    
                    <?php else: ?>
                        <h2>No Record Exists!</h2>
                    
                    <?php endif; ?>
                             
              </tbody>
              </table>
               
            </div>
            <!-- /.box-body -->
          </div>
       </div>
          <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>