<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Shipping Detail</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" method="post" action="<?php echo e(URL::to('admin/settings')); ?>">
                <?php echo e(Csrf_field()); ?>

              <div class="box-body">
                  <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">Shipping Price</label>
                  <div class="col-sm-10"> 
                      <input type="text"   class="form-control" name='ship_price' id="inputEmail3" value='<?php if(isset($ship->ship_price)): ?><?php echo e($ship->ship_price); ?><?php endif; ?>' >
                  </div>
                </div>
                  <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">Shipping Tax (%)</label>
                  <div class="col-sm-10"> 
                      <input type="text"   class="form-control" name='ship_tax' id="inputEmail3" value='<?php if(isset($ship->ship_price)): ?><?php echo e($ship->ship_tax); ?><?php endif; ?>'>
                  </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Tax (%)</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name='tax'  value='<?php if(isset($ship->ship_price)): ?><?php echo e($ship->tax); ?><?php endif; ?>' >
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Driver Tip</label>

                    <div class="col-sm-10">
                        <input type="text" class="form-control" name='driver_tip'  value='<?php if(isset($ship->ship_price)): ?><?php echo e($ship->driver_tip); ?><?php endif; ?>' >
                    </div>
                </div>  
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-info pull-right">Save</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>