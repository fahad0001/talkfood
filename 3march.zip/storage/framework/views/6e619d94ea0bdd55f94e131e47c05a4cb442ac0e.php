<?php $__env->startSection('style'); ?>
<style>

    .navbar-default .nav>li>a, .navbar-default .nav>li>a {
        color: #222 !important;
    }
    body {
        background-color: #f5f5f5 !important;
    }
    b, strong {
        font-weight: 500 !important;
    }

    .rest {
        color:#222;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('customer.layout.navigation2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section style="padding-top:70px;">

    <div class='container' >


        <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <h2>Cart</h2>
                <?php if(Session::has('cart') ): ?>
                <div class="table-responsive">
                  
                    <form action="<?php echo e(URL::to('/updatecart')); ?>" method="POST" >
                    <table class="table table-bordered">
                        <thead>
                            <tr> <th></th> <th>Item Name</th> <th>Item Description</th> <th>Item Quantity</th> <th>Item Price</th> </tr>
                        </thead> 
                        <tbody>
                            
                                    <?php echo e(csrf_field()); ?>

                            <?php $i=1;?>
                             <?php foreach($cart as $item): ?> 
                                <?php if(!is_array($item)): ?>
                                
                                <?php else: ?>
                                <tr> <th scope="row"><a href="<?php echo e(URL::to('/cart/delete')); ?>/<?php echo e($item['food_id']); ?>"><i class='fa fa-2x fa-close' style="color:red;"></i></a></th>
                                <td><?php echo e($item['food_name']); ?></td> 
                                <td><?php echo e($item['food_desc']); ?></td> 
                                <td><input type='number' name="items[<?php echo e($item['food_id']); ?>]" value='<?php echo e($item['quantity']); ?>' /></td> 
                                
                                <td><?php echo e($item['food_price']); ?></td>
                                
                            </tr> 
                                <?php endif; ?>
                              <?php endforeach; ?>
                              
                   
                        </tbody>
                    </table>
                         <button class="btn btn-primary" type="submit" >Update Cart</button>
                    </form>
                </div>
               

               <div class='col-md-4 col-md-push-8'>
                    <h1><b>Cart Totals</b></h1>
                   <div class="table-responsive">
                       <table class="table table-bordered"> 
                           
                           <tbody>
                               <tr>
                                   <td> <h4><b>Subtotal </b> </h4></td> 
                                   <td style='    vertical-align: middle;'>
                                       
                                   <?php echo e($subtotal); ?> CAD
                                   </td> 
                               </tr>
                               <tr>
                                   <td> <h4><b>Shipping </b> </h4></td> <td style='    vertical-align: middle;'><?php echo e($shipping); ?> CAD</td> 
                               </tr>
                               <tr>
                                   <td> <h4><b>Tax </b> </h4></td> <td style='    vertical-align: middle;'><?php echo e($tax); ?> CAD</td> 
                               </tr>
                                <tr>
                                   <td> <h4><b>Total </b> </h4></td> <td style='    vertical-align: middle;'><?php echo e($total); ?> CAD</td> 
                               </tr>
                           </tbody> 
                           
                   
                       </table>
                       <a href="<?php echo e(URL::to('cart/checkout')); ?>" class="btn btn-primary" type="submit" style='width:100%;'>Place Order<i class='fa fa-arrow-right'></i></a>
                       <H4><b>Note :Cash on Delivery</b></h4>
                   </div>
                  
                    
                  
                   
                   
                   
                  
                    
                </div>

                <?php else: ?> 
                
                <H1>Cart is empty !</H1>
                
              <?php endif; ?>



            </div>
         
        </div>

    </div>


</div>


</section>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>