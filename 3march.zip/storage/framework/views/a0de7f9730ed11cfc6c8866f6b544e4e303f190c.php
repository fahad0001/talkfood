<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
              <h3 class="box-title">Customers</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                  <tbody>
                <?php if(isset($rests)): ?>
                
                <tr>
                  <th>ID</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                   <th></th>
                   <th></th>
                </tr>
                
                        <?php foreach($rests as $rest): ?>
                            <tr>
                            <td><?php echo e($rest->id); ?></td>
                            <td><?php echo e($rest->first_name); ?></td>
                            <td><?php echo e($rest->last_name); ?></td>
                            <td><?php echo e($rest->email); ?></td>
                            <td><a href="<?php echo e(URL::to('admin/viewCustomerAddress')); ?>/<?php echo e($rest->id); ?>">View Deatails</a></td>
                            <td><a href="<?php echo e(URL::to('admin/deleteCustomer')); ?>/<?php echo e($rest->id); ?>">Delete</a></td>
                            </tr>                         
                        <?php endforeach; ?>
                    
                    <?php else: ?>
                        <h2>No Customer Exists!</h2>
                    
                    <?php endif; ?>
                             
              </tbody>
              </table>
                <div class="box-footer clearfix">
                    <ul class="pagination pagination-sm no-margin pull-right">
                        <?php echo $rests->render(); ?>
                    </ul>
                </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>