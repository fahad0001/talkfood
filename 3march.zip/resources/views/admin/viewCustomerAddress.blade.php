@extends('layout.master')
@section('title')
Restaurant Dashboard
@endsection


@section('content')
<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
                
            </div>
            <div class="box-body table-responsive no-padding">


                    <div class='row'>
            <div class='col-sm-12' style='background-color: white; padding-top:10px;padding-bottom:10px;min-height:500px;'>
                <div class="col-sm-6">
                     <h1>Customer Details</h1>
                    <h3><b>Customer Id : {{$custdetail->id}}</b></h3>
                    <h4>First Name  : {{$custdetail->first_name}}</h4>
                     <h4>Last Name : {{$custdetail->last_name}}</h4>
                  <h4>Email : {{$custdetail->email}}</h4>
                  
                </div>
                @foreach($custAddress as $i)
 <div class="col-sm-6">
 		@if($i->address_type==='ship')
                     <h3>Shipping Address</h3>
                    <h3>Street : {{$i->street}}</h3>
                    <h4>City : {{$i->city}}</h4>
                     <h4>State\Province : {{$i->state_province}}</h4>
                     <h4>Country : {{$i->country}}</h4>
                     <h4>Zip Code : {{$i->zip_code}}</h4>
                     <h4>Phone No : {{$i->phone_no}}</h4>
                </div>
                @elseif($i->address_type==='del')
                 <h3>Delivery Address</h3>
                    <h3>Street : {{$i->street}}</h3>
                    <h4>City : {{$i->city}}</h4>
                     <h4>State\Province : {{$i->state_province}}</h4>
                     <h4>Country : {{$i->country}}</h4>
                     <h4>Zip Code : {{$i->zip_code}}</h4>
                     <h4>Phone No : {{$i->phone_no}}</h4>
                </div>
                @elseif($i->address_type==='bill')
                 <h3>Billing Address</h3>
                    <h3>Street : {{$i->street}}</h3>
                    <h4>City : {{$i->city}}</h4>
                     <h4>State\Province : {{$i->state_province}}</h4>
                     <h4>Country : {{$i->country}}</h4>
                     <h4>Zip Code : {{$i->zip_code}}</h4>
                     <h4>Phone No : {{$i->phone_no}}</h4>
                </div>
                @endif
         @endforeach
     <a href="{{URL::to('admin/viewcustomer')}}" class="btn btn-danger"> Back to Customer</a>
            </div>
            </div>
           







                
            </div>
        </div>
        
    </div></div>
@endsection
