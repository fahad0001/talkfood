 @foreach($submenu as $d)

               
                <div class="col-md-12" style="overflow:hidden;">
                    <div class="col-xs-9">
                        <h3 ><b> {{$d->name}}</b></h3>
                        <h4>{{$d->desc}}</h4>


                    </div>
                    <div class="col-xs-3">
                        <h4><b>${{$d->price}} CAD</b><span style="text-decoration: none; color:#337ab7;" onclick="addtocartsub({{$d->id}})"> <i class="fa fa-2x fa-plus-square"style="vertical-align: middle;font-size: 25px;"></i></span></h4>


                    </div>
                </div>
               
              
                @endforeach