@extends('layout.master')
@section('title')
Restaurant Dashboard
@endsection


@section('content')
<div class="row">
<div class="col-md-8">
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add Menu Item</h3>
                </div>
    <form class="form-horizontal" role="form" action="{{URL::to('restaurant/addmenuitem')}}" method="POST">
         {{Csrf_field()}}
<div class="box-body">
        <div class="form-group">
            <label for="DishType" class="col-md-3 control-label">Category:</label>
            <div class="col-md-6">
               <select name="categ_id" class="form-control">
                            @foreach($categs as $categ)
                            <option value="{{ $categ->cate_id }}" > {{ $categ->cate_name }}</option>
                            @endforeach
                        </select>
                
            </div>
            
            
        </div>
    <div class="form-group">
        <label for="DishType" class="col-md-3 control-label">Item Name:</label>
            <div class="col-md-6">
                <input type="text" class="form-control" id="typename" name="food" placeholder="" required="">
                
            </div>
    </div>
        <div class="form-group">
            <label  class="col-md-3 control-label">Description:</label>
            <div class="col-md-6">
                <textarea type="textarea" class="form-control" id="typename" name="description"></textarea>
                
            </div>
        </div>
    <div class="form-group">
        <label  class="col-md-3 control-label">Price:</label>
            <div class="col-md-6">
                <input type="text" class="form-control" id="typename" name="price" placeholder="" required="">
                
            </div>
    </div>
    <div class="form-group">
                      <label class="col-md-3 control-label"> Sub Menu:
                         
                      </label>
        <div class="col-md-6" style="    padding-top: 8px;">
       
         
         
         <!-- sheepIt Form -->
<div id="sheepItForm">
 
  <!-- Form template-->
  <div id="sheepItForm_template">
        <label for="sheepItForm_#index#_phone">Submenu <span id="sheepItForm_label"></span></label>
         <a id="sheepItForm_remove_current">
     Remove
    </a>
   <div>
       <div class="form-group">
        <label for="sheepItForm_#index#_phone" class="col-md-4 control-label">Name <span id="sheepItForm_label"></span></label>
    <div class="col-md-6">
    <input id="sheepItForm_#index#_name" name="submenu[#index#][name]" type="text"/>
    </div>
       </div>
       <div class="form-group">
     <label for="sheepItForm_#index#_phone" class="col-md-4 control-label">Description <span id="sheepItForm_label"></span></label>
     <div class="col-md-6">
     <input id="sheepItForm_#index#_desc" name="submenu[#index#][desc]" type="text"/>
     </div>
       </div>
       <div class="form-group">
      <label for="sheepItForm_#index#_phone" class="col-md-4 control-label">Price <span id="sheepItForm_label"></span></label>
      <div class="col-md-6">
      <input id="sheepItForm_#index#_price" name="submenu[#index#][price]" type="text"/>
      </div>
       </div>
    </div>
  </div>
    
  <!-- /Form template-->
   
  <!-- No forms template -->
  <div id="sheepItForm_noforms_template">No Submenu</div>
  <!-- /No forms template-->
   
  <!-- Controls -->
  <div id="sheepItForm_controls">
    <div id="sheepItForm_add" class="pull-left" style="padding: 10px;"> <a class="btn btn-primary"><span>Add Submenu</span></a></div>
    <div id="sheepItForm_remove_last" class="pull-left" style="padding: 10px;"><a class="btn btn-primary"><span>Remove</span></a></div>
    
 
  <!-- /Controls -->
   
</div>
<!-- /sheepIt Form -->
         
         </div>
    </div>
       
    <div class="form-group">
        <div class="col-md-6 col-md-offset-3">            
            <button type="submit" class="btn btn-google">Submit</button>            
            </div>
    </div>
       <div class="box-body">
    </form>
    
</div>
</div>
    
</div>
</div>
<!--
Detail of the name used in the script
name for options:
email: menuoptionemail<incvalue>
description: menuoptiondesc<incvalue>
price: menuoption<incvalue>
-->
@endsection

@section('scripts')
<script>
    $(document).ready(function () {
       
         var sheepItForm = $('#sheepItForm').sheepIt({
        separator: '',
        allowRemoveLast: true,
        allowRemoveCurrent: true,
        allowRemoveAll: true,
        allowAdd: true,
        allowAddN: true,
        maxFormsCount: 10,
        minFormsCount: 0,
        iniFormsCount: 0
    });
       
       
       
        $("#submenu").click(function () {
            $("#submenutext").toggle();
        });

$( "#submenutext" )
  .keyup(function () {
      var bla = $('#submenutext').val();
      if(bla>10){
          $("#appendmenu").empty();
          $("#appendmenu").append('<h4 style="color:red">Values Greater than 10 are not accepted</h4>');
      }
      else{
        $("#appendmenu").empty();
        for(i=1; i<=bla; i++){
        $('#appendmenu').append(`<h3>Sub Item `+i+`</h3> 
                                <div class="box-body">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Name</label>
                                        <input name=menuoptionname`+i+` type="name" class="form-control"   placeholder="Enter Name"> 
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Description</label>
                                        <input name=menuoptiondesc`+i+` type="name" class="form-control"  placeholder="Enter Description">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Price</label>
                                        <input name=menuoptionprice`+i+` type="name" class="form-control"  placeholder="Enter Price">
                                    </div>
                                </div>`);
       
        }
      }
    });
});

</script>
@endsection

