<div class="user-panel">
        <div class="pull-left image">
          <img src="../../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Alexander Pierce</p>
        </div>
      </div>
<ul class="sidebar-menu">
    <li class="header">MAIN NAVIGATION</li>
    <li class="treeview">
        <a href="index">
            <i class="fa fa-dashboard"></i> <span>Order</span>
            <span class="pull-right-container">
              <!--<i class="fa fa-angle-left pull-right"></i>-->
            </span>
        </a>

    </li>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-dashboard"></i> <span>Food</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <li class=""><a href="#"><i class="fa fa-circle-o"></i> Add Categories</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Add Food</a></li>
          </ul>
    </li>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-user"></i> <span>Profile Info</span>
            <span class="pull-right-container">
              <!--<i class="fa fa-angle-left pull-right"></i>-->
            </span>
        </a>
    </li>
</ul>